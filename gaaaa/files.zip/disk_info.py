"""
disk_info.py
------------
Recolecta información real de los discos del sistema.
Backlog ítem 3: Obtener información del sistema (discos)
Backlog ítem 4: Obtener fecha y hora del cliente
"""

import platform
import random
from datetime import datetime, timezone
from typing import Optional

try:
    import psutil
    PSUTIL_AVAILABLE = True
except ImportError:
    PSUTIL_AVAILABLE = False
    print("[ADVERTENCIA] psutil no instalado. Ejecuta: pip install psutil")


def _detect_disk_type(device: str) -> str:
    """
    Intenta detectar si el disco es SSD o HDD.
    En Linux se puede leer /sys/block/<dev>/queue/rotational.
    En otros sistemas retorna 'Desconocido'.
    """
    try:
        if platform.system() == "Linux":
            # Extraer nombre base del dispositivo (ej: /dev/sda -> sda)
            dev_name = device.replace("/dev/", "").rstrip("0123456789")
            rotational_path = f"/sys/block/{dev_name}/queue/rotational"
            with open(rotational_path, "r") as f:
                value = f.read().strip()
                return "HDD" if value == "1" else "SSD"
    except Exception:
        pass
    return "Desconocido"


def _simulate_iops() -> float:
    """
    Simula IOPS cuando psutil no puede medirlos directamente.
    Retorna un valor aleatorio realista entre 80 y 500.
    """
    return round(random.uniform(80.0, 500.0), 2)


def get_disk_metrics() -> Optional[dict]:
    """
    Detecta el primer disco del sistema y retorna sus métricas.
    Según el backlog: 'Reportar únicamente el primer disco detectado si existen múltiples.'

    Retorna un dict con la información del disco o None si falla.
    """
    if not PSUTIL_AVAILABLE:
        # Datos simulados si psutil no está disponible
        return {
            "disk_name": "SimulatedDisk",
            "disk_type": "SSD",
            "total_gb": 500.0,
            "used_gb": 120.0,
            "free_gb": 380.0,
            "iops": _simulate_iops(),
        }

    try:
        partitions = psutil.disk_partitions(all=False)
        if not partitions:
            return None

        # Tomar el primer disco (partición raíz preferida)
        target = None
        for p in partitions:
            if p.mountpoint == "/" or p.mountpoint == "C:\\":
                target = p
                break
        if target is None:
            target = partitions[0]

        usage = psutil.disk_usage(target.mountpoint)

        total_gb = round(usage.total / (1024 ** 3), 2)
        used_gb  = round(usage.used  / (1024 ** 3), 2)
        free_gb  = round(usage.free  / (1024 ** 3), 2)

        # Intentar leer IOPS reales (solo Linux con contadores disponibles)
        iops = _simulate_iops()
        try:
            counters = psutil.disk_io_counters(perdisk=False)
            if counters:
                iops = round((counters.read_count + counters.write_count) / 1.0, 2)
        except Exception:
            pass

        disk_type = _detect_disk_type(target.device)

        return {
            "disk_name": target.device,
            "disk_type": disk_type,
            "total_gb": total_gb,
            "used_gb": used_gb,
            "free_gb": free_gb,
            "iops": iops,
        }

    except Exception as e:
        print(f"[ERROR] No se pudo obtener info del disco: {e}")
        return None


def get_report_timestamp() -> str:
    """
    Retorna la fecha y hora actual en formato ISO 8601 con zona horaria UTC.
    Backlog ítem 4.
    """
    return datetime.now(timezone.utc).isoformat()
