"""
report_builder.py
-----------------
Construye el JSON oficial del reporte que se envia al servidor.
Backlog item 5: Construir el JSON oficial del reporte.
Backlog item 11: Preparar estructura para futuras modificaciones (RAM, MAC, IP).
"""

import json
from typing import Optional
from disk_info import get_disk_metrics, get_report_timestamp
from config import NODE_CODE, INTERVAL_SECONDS


def build_report() -> Optional[str]:
    """
    Construye y valida el JSON del reporte.

    Estructura:
    {
        "node_code": "nodo_lapaz",
        "client_reported_at": "2026-03-03T12:00:00+00:00",
        "interval_seconds": 10,
        "disks": [ { disco... } ],
        "extra": {}
    }

    Retorna el JSON como string, o None si no hay datos de disco.
    """
    disk = get_disk_metrics()
    if disk is None:
        print("[ERROR] No se pudo obtener metricas del disco. No se enviara reporte.")
        return None

    report = {
        "node_code": NODE_CODE,
        "client_reported_at": get_report_timestamp(),
        "interval_seconds": INTERVAL_SECONDS,
        "disks": [disk],
        # Seccion extra lista para futuras expansiones (item 11)
        # Para activar, descomentar y completar los campos:
        "extra": {
            # "local_ip": None,
            # "mac_address": None,
            # "ram_total_gb": None,
            # "ram_used_gb": None,
        }
    }

    # Validar que el JSON esta bien formado
    try:
        json_str = json.dumps(report, ensure_ascii=False)
        json.loads(json_str)  # segunda pasada para verificar parsing
        return json_str
    except (TypeError, ValueError) as e:
        print(f"[ERROR] JSON mal formado: {e}")
        return None
