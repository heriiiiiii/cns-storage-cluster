"""
client.py
Punto de entrada principal del cliente CNS.
Item 1: Estructura base del cliente.
"""
import sys
from config import NODE_CODE, SERVER_HOST, SERVER_PORT, INTERVAL_SECONDS
from connection import run_client

SEP = "=" * 50

def main():
    print(SEP)
    print(" CLIENTE CNS - Nodo Regional")
    print(SEP)
    print(f" Nodo      : {NODE_CODE}")
    print(f" Servidor  : {SERVER_HOST}:{SERVER_PORT}")
    print(f" Intervalo : {INTERVAL_SECONDS}s")
    print(SEP)
    print()
    try:
        run_client()
    except KeyboardInterrupt:
        print("[INFO] Cliente detenido manualmente.")
        sys.exit(0)

if __name__ == "__main__":
    main()
