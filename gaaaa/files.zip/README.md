# Cliente CNS - Nodo Regional
## Practica 1: Implementacion de Sockets - Sistemas Distribuidos

### Estructura del proyecto

cliente_sockets/
    client.py           # Punto de entrada - ejecutar este archivo
    config.py           # Configuracion (carga .env)
    connection.py       # Logica TCP: conexion, envio y reconexion automatica
    disk_info.py        # Recoleccion de metricas reales del disco
    report_builder.py   # Construccion del JSON oficial del reporte
    message_handler.py  # Recepcion de mensajes del servidor + ACK
    logger.py           # Escritura en client.log
    .env                # Variables de entorno (EDITAR AQUI)
    requirements.txt    # Dependencias

### Instalacion

    pip install -r requirements.txt

### Configuracion

Edita el archivo  antes de ejecutar:

    NODE_CODE=nodo_lapaz        # Cambia al nombre de tu nodo
    SERVER_HOST=192.168.1.100   # IP del servidor de tus companeros
    SERVER_PORT=5000            # Puerto TCP del servidor
    INTERVAL_SECONDS=10         # Cada cuantos segundos se envia un reporte
    RECONNECT_WAIT=5            # Segundos antes de reintentar conexion

### Ejecucion

    python client.py

### Backlog completado

- [x] Item 1: Estructura base del cliente
- [x] Item 2: Conexion TCP al servidor
- [x] Item 3: Obtencion real de metricas del disco (psutil)
- [x] Item 4: Fecha y hora del cliente (ISO 8601 UTC)
- [x] Item 5: JSON oficial del reporte
- [x] Item 6: Envio periodico automatico
- [x] Item 7: Reconexion automatica si el servidor cae
- [x] Item 8: Recepcion de mensajes del servidor (hilo separado)
- [x] Item 9: Guardado de mensajes en client.log
- [x] Item 10: Confirmacion ACK al servidor
- [x] Item 11: Seccion extra preparada para RAM, MAC, IP

### Formato JSON enviado al servidor

    {
        node_code: nodo_lapaz,
        client_reported_at: 2026-03-03T12:00:00+00:00,
        interval_seconds: 10,
        disks: [
            {
                disk_name: /dev/sda,
                disk_type: SSD,
                total_gb: 500.0,
                used_gb: 120.0,
                free_gb: 380.0,
                iops: 245.5
            }
        ],
        extra: {}
    }

### Formato ACK enviado al servidor

    {
        type: ACK,
        message_id: uuid-del-mensaje
    }
